package com.spring.rest.react.demo.Controller;
import com.spring.rest.react.demo.Model.Skill;
import com.spring.rest.react.demo.Service.SkillServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping(value="/skill")
public class SkillController
{

    @Autowired
    SkillServices skillServices;

    @GetMapping("/")
    public List<Skill> metoda1() throws Exception {
        return  skillServices.findAll();
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public Skill post(@RequestBody Skill skill) {
        return skillServices.save(skill);
    }

    @DeleteMapping(value="/{jakiesId}")
    public void metodaDelete(@PathVariable Integer  jakiesId) {
        skillServices.deleteById(jakiesId);
    }

    @PutMapping(value="/{id}")
    public void updateSkill(@PathVariable Integer id, @RequestBody Skill skill) {
        System.out.println("id: "+id);
        this.skillServices.updateSkill(id, skill);
    }
}
