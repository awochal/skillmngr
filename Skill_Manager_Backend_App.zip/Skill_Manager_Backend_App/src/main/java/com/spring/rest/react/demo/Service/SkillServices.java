package com.spring.rest.react.demo.Service;

import com.spring.rest.react.demo.Model.Skill;
import com.spring.rest.react.demo.Repository.SkillRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillServices {

    SkillRepo skillRepo;

    @Autowired
    SkillServices(SkillRepo skillRepo) {
        this.skillRepo = skillRepo;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void anyWithoutName() {

        skillRepo.save(Skill.builder().name("Java").level(80).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("Spring").level(60).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("Algorithms & data structures").level(70).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("SQL").level(50).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("Testing").level(5).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("Node js").level(0).contentGroup(1).build());
        skillRepo.save(Skill.builder().name("HTML5").level(50).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("CSS3").level(50).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("React").level(50).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("Bootstrap").level(20).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("JavaScript").level(10).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("Angular").level(0).contentGroup(2).build());
        skillRepo.save(Skill.builder().name("Testing").level(70).contentGroup(2).build());

    }

    public List<Skill> findAll() {
        return skillRepo.findAll();
    }


    public Skill save(Skill skill) {
        System.out.println(skill);
        return skillRepo.save(skill);
    }


    public void deleteById(Integer jakiesId) {
        skillRepo.deleteById(jakiesId);
    }

    public void updateSkill(Integer id, Skill skill) {
        skillRepo.save(skill);
    }
}

