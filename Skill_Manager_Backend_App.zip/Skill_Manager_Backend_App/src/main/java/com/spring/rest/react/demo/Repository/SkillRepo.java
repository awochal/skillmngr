package com.spring.rest.react.demo.Repository;

import com.spring.rest.react.demo.Model.Skill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.*;

@Repository
public interface SkillRepo extends JpaRepository<Skill, Integer> {
}