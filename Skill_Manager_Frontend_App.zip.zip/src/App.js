import foto from './foto1.PNG';

import './App.css';
import Skills from './components/Skills';
import React from 'react';

function App() {

    const [appState, setAppState] = React.useState({ skills: [] })
    const [skillFromForm1, setSkillFromForm1] = React.useState({ name: "", level: 50, contentGroup: 1 })
    const [skillFromForm2, setSkillFromForm2] = React.useState({ name: "", level: 50, contentGroup: 2 })

    React.useEffect(() => {
        const url = "http://localhost:8080/skill/";
        fetch(url)
            .then(data => data.json())
            .then(response => setAppState({ skills: response }));
    }, [])
    function upgradeSkill(id, skill) {
        const url="http://localhost:8080/skill/"+id
        if(skill.level<100){skill={...skill, level:skill.level+1}}
        fetch(url, {
            method: "PUT",
            headers: { 'Content-Type': "application/json" },
            body: JSON.stringify(skill)
        }
            )
        setAppState(
            (appState) => {
                return (
                    {
                        skills:
                            appState.skills.map((item)=>{return (item.id==skill.id?{...skill, level: skill.level}:item)})
                    }
                )
            }
        )
        console.log("skill upgraded" + id)
    }

    function downgradeSkill(id, skill) {
        const url="http://localhost:8080/skill/"+id
        if(skill.level>0){skill={...skill, level:skill.level-1}}
        fetch(url, {
            method: "PUT",
            headers: { 'Content-Type': "application/json" },
            body: JSON.stringify(skill)
        }
            )
        setAppState(
            (appState) => {
                return (
                    {
                        skills:
                            appState.skills.map((item)=>{return (item.id==skill.id?{...skill, level: skill.level}:item)})
                    }
                )
            }
        )
        console.log("skill upgraded" + id)
    }

    function deleteSkill(id) {
        const url = "http://localhost:8080/skill/"+id;
        fetch(url, {
            method: "DELETE",
        })
        setAppState(
            (appState) => {
                return (
                    {
                        skills:
                            appState.skills.filter(skill=>skill.id!==id)
                      }
                )
            }
        )
        console.log("skill upgraded" + id)
    }

    function updateSkillFromForm1(event) {
        setSkillFromForm1(
            (prevSkill) => {
                return (
                    { ...prevSkill, [event.target.name]: event.target.value }
                )
            }
        )
        console.log(skillFromForm1)
    }

    
    function updateSkillFromForm2(event) {
        setSkillFromForm2(
            (prevSkill) => {
                return (
                    { ...prevSkill, [event.target.name]: event.target.value }
                )
            }
        )
        console.log(skillFromForm2)
    }

    function addSkill(contentGroup, e) {
        e.preventDefault(); //input submit nie wykona standarowej akcji (wysłania formularza)
        e.stopPropagation(); //strona nie przeładuje się
        const url = "http://localhost:8080/skill/";
        fetch(url, {
            method: "POST",
            headers: { 'Content-Type': "application/json" },
            body: JSON.stringify(contentGroup=='1'?skillFromForm1:skillFromForm2)  //określamy ciało przesyłanej wiadomości
        })
        .then(data => data.json())
            .then((response) => {
                setAppState(
                    (prevState) => {
                        return (
                            {
                                ...prevState, skills:
                                    [...prevState.skills, response]
                            }
                        )
                    }
                )
            })
    setSkillFromForm1(
        (prevSkill) => {
            return (
                { ...prevSkill, name: "" }
            )
        }
    )
    setSkillFromForm2(
        (prevSkill) => {
            return (
                { ...prevSkill, name: "" }
            )
        }
    )
           
    }

    return (
        <div className='App'>


            {/*second row*/}
            <div></div>
            <div className="MainWindow Skills1">
                <Skills title="Backend Skills" contentGroup='1' skills={appState.skills} skillFromForm1={skillFromForm1} skillFromForm2={skillFromForm2} addSkill={addSkill} updateSkillFromForm1={updateSkillFromForm1} updateSkillFromForm2={updateSkillFromForm2} downgradeSkill={downgradeSkill} upgradeSkill={upgradeSkill} deleteSkill={deleteSkill}/>
            </div>
            <div  className="MainWindow"><img src={foto}></img></div>
            <div className="MainWindow Skills2">
                <Skills title="Frontend Skills"  contentGroup='2' skills={appState.skills} skillFromForm1={skillFromForm1}  skillFromForm2={skillFromForm2} addSkill={addSkill} updateSkillFromForm1={updateSkillFromForm1} updateSkillFromForm2={updateSkillFromForm2} downgradeSkill={downgradeSkill} upgradeSkill={upgradeSkill} deleteSkill={deleteSkill}/>
            </div>
            <div></div>

            {/*third row*/}
            <div></div>
            
            <div className='MainWindow AutoOverflow Footer'>Backend app allowing connectivity with SQL database is not available online. To have this page working, please download <a href="https://github.com/awochal/skillmngr">backend application</a> and deploy on localhost:8080</div>
            
            <div></div>

        </div>
    )
}

export default App;
