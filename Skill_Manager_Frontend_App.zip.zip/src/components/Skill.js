import React from "react";
import java from "../java.png"

export default function Skill(props) {
    return (
        
        <div className="FrontEndSkill">
            <div className="Cell NamePadding Text2"><span className="Middle">{props.skill.name}</span></div>
            <div className="Cell BarPadding">
                <button onClick={() => props.downgradeSkill(props.skill.id, props.skill)}>-</button>
                <progress id="skill" value={props.skill.level} max="100"></progress>
                <button onClick={() => props.upgradeSkill(props.skill.id, props.skill)}>+</button>
                <button onClick={() => props.deleteSkill(props.skill.id)}>x</button>
            </div>
        </div>

    )
}