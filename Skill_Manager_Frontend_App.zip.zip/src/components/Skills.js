import React from "react";
import Skill from "./Skill";
import SkillForm from "./SkillForm";

export default function Skills(props) {
    return (
        <div>
            <div className="Padding"><div className="Header">{props.title}</div></div>
            <div className="AutoOverflow SkillsList">
            {props.skills.filter(
                (skill)=>{return (
                    skill.contentGroup==props.contentGroup
                )
                }
            ).map((skill) => {
                return (
                    <Skill skill={skill} upgradeSkill={props.upgradeSkill} downgradeSkill={props.downgradeSkill} deleteSkill={props.deleteSkill}/>
                )
            })}
            </div>
            <div>
                <SkillForm contentGroup={props.contentGroup} skillFromForm1={props.skillFromForm1} updateSkillFromForm1={props.updateSkillFromForm1} skillFromForm2={props.skillFromForm2} updateSkillFromForm2={props.updateSkillFromForm2} addSkill={props.addSkill}/>
            </div>
            </div>
    )
        }
