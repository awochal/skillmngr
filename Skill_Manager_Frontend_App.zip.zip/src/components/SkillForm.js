import React from "react";
import java from "../java.png"
export default function SkillForm(props){
    return (
        <form onSubmit={(e)=>props.addSkill(props.contentGroup, e)}>
        <div className="FrontEndForm">
            <div className="Button">
                <input type="text" pattern="[A-Za-z]{2-50}" required name="name"  placeholder="Enter name here" value={props.contentGroup=='1'?props.skillFromForm1.name:props.skillFromForm2.name} onChange={props.contentGroup=='1'?props.updateSkillFromForm1:props.updateSkillFromForm2}></input>
            </div>
            <div className="Button">
                <button className="BigButton">Add new skill</button>
            </div>
        </div>
        </form>
        )
}